% Script to plot multiple Tunguska strewn field 
%
% Albino Carbognani, INAF-OAS
% Version Oct 6, 2023

clear all

% Strewn field with i=35�, Gamma=0.775
s3='Monte_Carlo_strewn_field_MS_1533_Ga_0.775_I_35.txt';
Dat3(:,:)=load(s3, '-ascii');
LAT_MC3=Dat3(:, 1);           % Lat (deg)
LONG_MC3=Dat3(:, 2);          % Long (deg)

s4='Monte_Carlo_strewn_field_MS_2902_Ga_0.775_I_35.txt';
Dat4(:,:)=load(s4, '-ascii');
LAT_MC4=Dat4(:, 1);           % Lat (deg)
LONG_MC4=Dat4(:, 2);          % Long (deg)

s5='Monte_Carlo_strewn_field_MS_3126_Ga_0.775_I_35.txt';
Dat5(:,:)=load(s5, '-ascii');
LAT_MC5=Dat5(:, 1);           % Lat (deg)
LONG_MC5=Dat5(:, 2);          % Long (deg)

s6='Monte_Carlo_strewn_field_MS_3322_Ga_0.775_I_35.txt';
Dat6(:,:)=load(s6, '-ascii');
LAT_MC6=Dat6(:, 1);           % Lat (deg)
LONG_MC6=Dat6(:, 2);          % Long (deg)

% Unione degli strewn field
LAT_MC=[LAT_MC3' LAT_MC4' LAT_MC5' LAT_MC6'];
LONG_MC=[LONG_MC3' LONG_MC4' LONG_MC5' LONG_MC6'];

figure
nbins=[15 15];
[Nc,C]=hist3([LONG_MC', LAT_MC'],nbins); % Matrice con la distribuzione dei punti di impatto virtuali
contour(C{1},C{2},Nc,[5 47 424]); % Plot della distribuzione dei punti con curva di livello scelte in modo tale che la
% probabilit� di avere un punto all'interno della curva di livello sia quella della gaussiana: 68% per 1 sigma, 95,4% per 2 sigma e 99,7% per 3 sigma.
prob1_6=100*sum(Nc((Nc(:) >= 424)))/length(LONG_MC); % Probabilit� di cadere dentro 1 sigma
prob2_6=100*sum(Nc((Nc(:) >= 47)))/length(LONG_MC);  % Probabilit� di cadere dentro 2 sigma
prob3_6=100*sum(Nc((Nc(:) >= 5)))/length(LONG_MC);  % Probabilit� di cadere dentro 3 sigma
hold on
plot(101.894, 60.886, 'r+', 'MarkerSize', 15, 'LineWidth', 3) % Tunguska Epicenter
hold on
plot(101.9167, 60.8967, 'b*', 'MarkerSize', 18, 'LineWidth', 3) % John's Stone
hold on
plot(101.860278, 60.96389, 'c.', 'MarkerSize', 50) % Cheko Lake
grid
axis equal
legend("Probability distribution","Tunguska Epicenter","John's Stone", "Cheko Lake",'interpreter','latex')
title('Tunguska''s Strewn field $i=35^\circ$', 'FontSize',14,'interpreter','latex')
xlabel('Long. (deg)','FontSize',20)
ylabel('Lat. (deg)','Fontsize',20)

% figure
% %plot(LONG_MC6, LAT_MC6, 'b.', 'MarkerSize', 20)
% nbins=[15 15];
% [Nc6,C6]=hist3([LONG_MC6,LAT_MC6],nbins); % Matrice con la distribuzione dei punti di impatto virtuali
% contour(C6{1},C6{2},Nc6,[2 12 96]); % Plot della distribuzione dei punti con curva di livello scelte in modo tale che la
% % probabilit� di avere un punto all'interno della curva di livello sia quella della gaussiana: 68% per 1 sigma, 95,4% per 2 sigma e 99,7% per 3 sigma.
% prob1_6=100*sum(Nc6((Nc6(:) >= 96)))/length(LONG_MC6); % Probabilit� di cadere dentro 1 sigma
% prob2_6=100*sum(Nc6((Nc6(:) >= 12)))/length(LONG_MC6);  % Probabilit� di cadere dentro 2 sigma
% prob3_6=100*sum(Nc6((Nc6(:) >= 2)))/length(LONG_MC6);  % Probabilit� di cadere dentro 3 sigma
% hold on
% %plot(LONG_MC5, LAT_MC5, 'g.', 'MarkerSize', 15)
% [Nc5,C5]=hist3([LONG_MC5,LAT_MC5],nbins); % Matrice con la distribuzione dei punti di impatto virtuali
% contour(C5{1},C5{2},Nc5,[2 11 86]); % Plot della distribuzione dei punti con curva di livello scelte in modo tale che la
% % probabilit� di avere un punto all'interno della curva di livello sia quella della gaussiana: 68% per 1 sigma, 95,4% per 2 sigma e 99,7% per 3 sigma.
% prob1_5=100*sum(Nc5((Nc5(:) >= 86)))/length(LONG_MC5); % Probabilit� di cadere dentro 1 sigma
% prob2_5=100*sum(Nc5((Nc5(:) >= 11)))/length(LONG_MC5);  % Probabilit� di cadere dentro 2 sigma
% prob3_5=100*sum(Nc5((Nc5(:) >= 2)))/length(LONG_MC5);  % Probabilit� di cadere dentro 3 sigma
% hold on
% %plot(LONG_MC4, LAT_MC4, 'r.', 'MarkerSize', 10)
% [Nc4,C4]=hist3([LONG_MC4,LAT_MC4],nbins); % Matrice con la distribuzione dei punti di impatto virtuali
% contour(C4{1},C4{2},Nc4,[2 11 96]); % Plot della distribuzione dei punti con curva di livello scelte in modo tale che la
% % probabilit� di avere un punto all'interno della curva di livello sia quella della gaussiana: 68% per 1 sigma, 95,4% per 2 sigma e 99,7% per 3 sigma.
% prob1_4=100*sum(Nc4((Nc4(:) >= 96)))/length(LONG_MC4);  % Probabilit� di cadere dentro 1 sigma
% prob2_4=100*sum(Nc4((Nc4(:) >= 11)))/length(LONG_MC4);  % Probabilit� di cadere dentro 2 sigma
% prob3_4=100*sum(Nc4((Nc4(:) >= 2)))/length(LONG_MC4);   % Probabilit� di cadere dentro 3 sigma
% hold on
% plot(101.894, 60.886, 'r+', 'MarkerSize', 15, 'LineWidth', 3) % Tunguska Epicenter
% hold on
% plot(101.9167, 60.8967, 'b*', 'MarkerSize', 18, 'LineWidth', 3) % John's Stone
% hold on
% plot(101.860278, 60.96389, 'c.', 'MarkerSize', 50) % Cheko Lake
% grid
% legend("$m_{fr}$=6000 kg", "$m_{fr}$=5000 kg", "$m_{fr}$=4000 kg","Tunguska Epicenter","John's Stone", "Cheko Lake",'interpreter','latex')
% title('Tunguska''s Strewn field $i=35^\circ$', 'FontSize',14,'interpreter','latex')
% xlabel('Long. (deg)','FontSize',20)
% ylabel('Lat. (deg)','Fontsize',20)