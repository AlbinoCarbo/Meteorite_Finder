% Meteorite Finder for Tunguska strewn field (SPECIAL EDITION)
% Matlab script for the computation of dark flight and strewn field of a single meteoroid in a 3D ECEF system. 
% Input data with initial conditions are read from the Settings.txt file. It needs 
% the atmospheric profile, from the starting dark flight point to the ground.
%
% ALGORITHM
% 1-Read settings file
% 2-Copy file "Settings.txt" in fireball's folder
% 3-Compute and save file "meteoroid_data.txt" in main folder to be read from ODEsystem.m script
% 4-Define working path and atmospheric profile location
% 5-Compute ECEF atmospheric profile from geopotential atmospheric profile 
%   and save ECEF "atmospheric_data.txt" in main folder to be read from ODEsystem.m script
% 6-Copy file "atmospheric_data.txt" also in fireball's folder
% 7-Compute meteoroid starting speed in ECEF reference system
% 8-Compute meteoroid starting position in ECEF reference system
% 9-Define starting conditions vector
% 10-Integrate 3D motion equations with Runge-Kutta 4th/5th order ODE
%    solver taking into account Coriolis and centrifugal forces (ODEsystem.m script)
% 11-Select physical solution (only points above Earth's surface)
% 12-Compute meteoroid speed module
% 13-Compute meteoroid height above surface, Lat and Long WGS84
% 14-Monte Carlo computation for uncertainty on Lat and Long of the nominal impact point (if selected in "Settings.txt")
% 15-Save the Monte Carlo results in output file "Monte_Carlo_strewn_field.txt" (in fireball's folder)
% 16-Save the nominal results in output file "Dark_flight_strewn_field.txt" (in fireball's folder)
% 17-Save nominal dark flight trajectory in .kml files for Google Earth (in fireball's folder)
% 18-Save strewn field in .kml files for Google Earth (in fireball's folder)
% 19-Plot and save in fireball's folder dark flight and strewn field model results
% 20-End script
%
% Matlab's functions:
%
% [U,V,W] = ned2ecefv(uNorth,vEast,wDown,lat0,lon0) 
% returns vector components U, V, and W in a geocentric Earth-centered Earth-fixed (ECEF) system 
% corresponding to vector components uNorth, vEast, and wDown in a local north-east-down (NED) system. 
% Specify the origin of the system with the geodetic coordinates lat0 and lon0. 
% Each coordinate input argument must match the others in size or be scalar.
%
% [X,Y,Z] = geodetic2ecef(spheroid,lat,lon,h) transforms the geodetic coordinates specified by lat, lon, and h 
% to the geocentric Earth-Centered Earth-Fixed (ECEF) Cartesian coordinates specified by X, Y, and Z. 
% Specify spheroid as the reference spheroid for the geodetic coordinates.
%
% interpolation.m, function for the linear interpolation of wind speed, air density and temperature 
% between two different altitudes of the atmospheric profile.
%
% Monte_Carlo_meteoroid.m, function for computing the uncertainty of the falling point of a 
% meteoroid using the Monte Carlo method.
% 
% Albino Carbognani, INAF-OAS
% Version Mar 23, 2023

clear all

disp('                                                                       ')
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
disp('%                     METEORITE FINDER FOR TUNGUSKA                   %')
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
disp('%               DARK FLIGHT AND STREWN FIELD COMPUTATION              %')
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
disp('                                                                       ')
disp('                    by Albino Carbognani (INAF-OAS)                    ')
disp('                              Mar 2023                                 ')
disp('                                                                       ')
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
disp('   ')

% Reference ellipsoid for World Geodetic System of 1984.
% NOTE: by default, the lengths of the semimajor axis and semiminor axis are in
% meters.
wgs84 = wgs84Ellipsoid;

%%%%%%%%%%%%%%%%%%%%%%
% Read settings file %
%%%%%%%%%%%%%%%%%%%%%%
disp('Read settings file')
disp('   ')

wholefile_set = fileread('.\Settings.txt');
% Split of the Settings and initialization of the string variables
set = regexp(wholefile_set,'\$+','split');

fireball_name=strtrim(set{4});         % Fireball's folder name
WP=strtrim(set{7});                    % Working path of the script
ATMO=strtrim(set{10});                 % Atmospheric profile name
M0=str2double(strtrim(set{13}));       % Meteoroid mass, kg
rho_M=str2double(strtrim(set{16}));    % Mean density meteoroid, kg/m^3
V0=str2double(strtrim(set{19}));       % Starting speed, m/s
I0=str2double(strtrim(set{22}));       % Trajectory inclination at starting speed, degrees
A0=str2double(strtrim(set{25}));       % Trajectory azimut at starting speed, degrees
Q0=str2double(strtrim(set{28}));       % Starting height above Earth surface, m
LAT=str2double(strtrim(set{31}));      % Latitude starting point, degrees
LONG=str2double(strtrim(set{34}));     % Longitude starting point, degrees
Qfin=str2double(strtrim(set{37}));     % Mean elevation of the ground (estimated) on which the meteoroid falls, m
T0=str2double(strtrim(set{40}));       % Maximum integration time, s
Ga=str2double(strtrim(set{43}));       % Asintotic drag coefficient
F=str2double(strtrim(set{46}));        % Dimensionless spherical form factor
Monte_Carlo=str2double(strtrim(set{49}));  % Monte Carlo selection (1=no, 2=yes) 
Number_MC=str2double(strtrim(set{52}));    % Number of Monte Carlo scenarios

% Copy the current settings file in the current fireball's folder
copyfile("Settings.txt", fireball_name)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute and save meteoroid data %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Compute and save meteoroid data for ODEsystem.m script')
disp('   ')

% Compute meteoroid effective radius, m
R0=(3*M0/(4*pi*rho_M))^(1/3);

% Compute effective cross section meteoroid, m^2
S0=F*(M0/rho_M)^(2/3);

% Save data in "meteoroid_data.txt", file that will be read by ODEsystem.m
fid0 = fopen('meteoroid_data.txt','w');
fprintf(fid0,'%10.3f \t %10.3f \t %10.3f\n', F, Ga, rho_M);   
fclose(fid0);

% Copy the current meteoroid file in the current fireball's folder
copyfile("meteoroid_data.txt", fireball_name)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define path and atmospheric data %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp('Define working path and atmospheric data location')
disp('   ')

working_path=strcat(WP, fireball_name);  
atmospheric_profile=strcat(working_path, '/', ATMO);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute and save "atmospheric_data.txt" from ATMO %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
string1=strcat('Compute and save ECEF atmospheric data from', " ", ATMO);
disp(string1)
disp('   ')

s0=atmospheric_profile;
Dat(:,:)=load(s0, '-ascii');
pres=Dat(:, 1)';                            % Pressure, hPa
ugr=Dat(:, 2)';                             % Wind u speed, m/s
vgr=Dat(:, 3)';                             % Wind v speed, m/s
temp=Dat(:, 4)';                            % Temperature, K
quota_vento=Dat(:, 6)';                     % Quote, m

density=0.1*(3.483676*pres./temp);          % Air density, kg/m^3
Vw_north=vgr;                               % Wind speed north component, m/s
Vw_east=ugr;                                % Wind speed east component, m/s

% Computation of wind speed components in the ECEF system, m/s
[VX, VY, VZ]=ned2ecefv(Vw_north, Vw_east, 0, LAT, LONG);

% Save atmospheric ECEF profile in current "atmospheric_data.txt", file that will be read by ODEsystem.m
fid = fopen('atmospheric_data.txt','w');
for i=1:length(quota_vento)
fprintf(fid,'%10.3f \t %10.3f \t %10.3f  %10.3f  %10.3f \t %10.3f\n', quota_vento(i), temp(i), density(i), VX(i), VY(i), VZ(i)); 
end

% Close the file atmospheric_profile.txt
fclose(fid);

% Copy the current atmospheric data file in the current fireball's folder
copyfile("atmospheric_data.txt", fireball_name)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute meteoroid starting speed in ECEF reference system %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Compute meteoroid starting speed in ECEF reference system')
disp('   ')

V_north=-V0*cosd(I0)*cosd(A0); % Speed component towards north, m/s
V_east=-V0*cosd(I0)*sind(A0);  % Speed component towards east, m/s
V_down=V0*sind(I0);            % Speed component down, m/s

[VX0, VY0, VZ0]=ned2ecefv(V_north, V_east, V_down, LAT, LONG);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute meteoroid starting position in ECEF reference system %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Compute meteoroid starting position in ECEF reference system')
disp('   ')

% Compute ECEF coordinates of starting point, m 
[X0, Y0, Z0] = geodetic2ecef(wgs84,LAT,LONG,Q0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Vector of starting conditions, speed (km/s) and position (m), in ECEF system %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Define starting conditions vector')
disp('   ')

y0=[VX0 VY0 VZ0 X0 Y0 Z0 M0];

% Integration time vector, s
tspan=0:0.01:T0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Numerical integration of the equations of motion %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Integrate motion equations')
disp('   ')

% Runge-Kutta 4th/5th order ODE solver
[t, y]=ode45(@ODEsystem, tspan, y0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Select physical solution, i.e. height >= Qfin %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
disp('Select physical solution')
disp('   ')

N=0;

for i=1:length(y(:,4))
   [~,~,quota_meteoroide]=ecef2geodetic(wgs84, y(i, 4), y(i, 5), y(i, 6));
   if quota_meteoroide - Qfin >= 0 
       N=N+1;
   end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute meteoroid speed %
%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Compute meteoroid speed')
disp('   ')

speed=zeros(1, N);
for i=1:N
    speed(i)=sqrt(y(i, 1)^2+y(i, 2)^2+y(i, 3)^2);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute meteoroid height, lat and long %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Compute meteoroid height, lat and long')
disp('   ')

height=zeros(1, N);
lat=zeros(1, N);
long=zeros(1, N);

for i=1:N
    [lat(i), long(i), height(i)]=ecef2geodetic(wgs84, y(i, 4), y(i, 5), y(i, 6));
end

% Compute residual mass, kg
M1=y(N, 7);

% Compute meteoroid effective radius, m
R1=(3*y(N, 7)/(4*pi*rho_M))^(1/3);

% Compute effective cross section meteoroid, m^2
S1=F*(y(N, 7)/rho_M)^(2/3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Optional Monte Carlo computation %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if Monte_Carlo==2
    [LAT_MC, LONG_MC]=Monte_Carlo_meteoroid(Number_MC, N);
    % Compute strewn field extension (1 sigma) in km
    [~, sigma_X, ~, sigma_Y]=strewn_field_extensions(lat(N), long(N), A0, LAT_MC, LONG_MC);
    
    disp('Save Monte Carlo strewn field in: Monte_Carlo_strewn_field.txt')
    disp('   ')
    filename1 = strcat(working_path, '/Monte_Carlo_strewn_field','_MS_', num2str(round(M0/S0)),'_Ga_',num2str(Ga),'_I_',num2str(I0), '.txt');
    fid1 = fopen(filename1,'w'); 
    fprintf(fid1, '%% Starting Mass (kg)                       %10.2f \n', M0);
    fprintf(fid1, '%% Starting diameter (m)                    %10.2f \n', 2*R0);
    fprintf(fid1, '%% Starting M/A (kg/m^2)                    %10.2f \n', M0/S0);
    fprintf(fid1, '%%    \n');
    fprintf(fid1, '%% Lat (degrees)     Long (degrees)        \n');
       for i=1:Number_MC
          fprintf(fid1,'%10.4f  \t\t %10.4f \n', LAT_MC(i), LONG_MC(i)); 
       end
    fprintf(fid1, '    \n');
    fclose(fid1);
    
else
    LAT_MC=lat(N); LONG_MC=long(N);
    disp('No Monte Carlo computation')
    disp('   ')
end

%%%%%%%%%%%%%%%%
% Save results %
%%%%%%%%%%%%%%%%

disp('Save the results in output file: Dark_flight_strewn_field.txt')
disp('   ')
filename0 = strcat(working_path, '/Dark_flight_strewn_field','_MS_', num2str(round(M0/S0)),'_Ga_',num2str(Ga),'_I_',num2str(I0), '.txt');
fid = fopen(filename0,'w'); 
fprintf(fid, '%%    \n');
fprintf(fid, '%% DARK FLIGHT AND STREWN FIELD - SINGLE BODY MODEL \n');
fprintf(fid, '%%    \n');
fprintf(fid, '%% Fireball name                            %s \n', fireball_name);
fprintf(fid, '%% Starting Mass (kg)                       %10.2f \n', M0);
fprintf(fid, '%% Starting diameter (m)                    %10.2f \n', 2*R0);
fprintf(fid, '%% Mean density (kg/m^3)                    %10.0f \n', rho_M);
fprintf(fid, '%% Starting M/A (kg/m^2)                    %10.2f \n', M0/S0);
fprintf(fid, '%% Asintotic drag coefficient               %10.2f \n', Ga);
fprintf(fid, '%% Starting speed (km/s)                    %10.2f \n', V0/1000);
fprintf(fid, '%% Starting inclination (degree)            %10.2f \n', I0);
fprintf(fid, '%% Starting height (km)                     %10.2f \n', Q0/1000);
fprintf(fid, '%% Starting Lat (degree)                    %10.4f \n', LAT);
fprintf(fid, '%% Starting Long (degree)                   %10.4f \n', LONG);
fprintf(fid, '%% Final Mass (kg)                          %10.2f \n', M1);
fprintf(fid, '%% Final diameter (m)                       %10.2f \n', 2*R1);
fprintf(fid, '%% Final M/A (kg/m^2)                       %10.2f \n', M1/S1);
fprintf(fid, '%% Final speed (km/h)                       %10.2f \n', 3.6*speed(N));
fprintf(fid, '%% Final height (km)                        %10.2f \n', height(N)/1000);
fprintf(fid, '%% Final Lat (degree)                       %10.4f pm %10.4f\n', lat(N), std(LAT_MC));
fprintf(fid, '%% Final Long (degree)                      %10.4f pm %10.4f\n', long(N), std(LONG_MC));
if Monte_Carlo==2
fprintf(fid, '%% 1 Sigma strewn field (orth. direction, km)  %10.2f \n', sigma_X);
fprintf(fid, '%% 1 Sigma strewn field (paral. direction, km) %10.2f \n', sigma_Y);
end
fprintf(fid, '%% Total fall time (s)                      %10.2f \n', t(N));
fprintf(fid, '%% Maximum integration time (s)             %10.2f \n', T0);
fprintf(fid, '    \n');
fprintf(fid, '%% Height (km)     Speed (km/s)       Lat (degrees)     Long (degrees)        Time (s)\n');
fprintf(fid, '    \n');

% Salvataggio dei valori del modello nel file di output
for i=1:N
     fprintf(fid,'%10.3f \t  %10.3f\t\t %10.4f  \t\t %10.4f \t\t %10.3f \n', height(i)/1000, speed(i)/1000, lat(i), long(i), t(i)); 
end
fprintf(fid, '    \n');
fclose(fid);

disp('Save dark flight trajectory in .kml files for Google Earth')
disp('   ')

% Syntax: kmlwriteline(filename,latitude,longitude)
% kmlwriteline(filename,latitude,longitude,altitude)
iconFilename1 = 'http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png';
iconFilename2 = 'http://maps.google.com/mapfiles/kml/shapes/star.png';
iconFilename3 = 'http://maps.google.com/mapfiles/kml/paddle/ylw-blank-lv.png';
% Array of white characters to not show the name near the icons in the kml file
Name_blank = blanks(length(lat));
filename1 = strcat(working_path, '/', fireball_name, '_Dark_flight_MS_', num2str(round(M0/S0)), '_Ga_',num2str(Ga), '.kml');
kmlwritepoint(filename1, lat(1:100:N)', long(1:100:N)', height(1:100:N)', 'Icon', iconFilename1, 'IconScale', 1, 'Name', Name_blank);

disp('Save strewn field in .kml files for Google Earth')
disp('   ')
Name_blank2 = blanks(length(LONG_MC));
filename2 = strcat(working_path, '/', fireball_name, '_Strewn_field_MS_', num2str(round(M0/S0)), '_Ga_',num2str(Ga), '.kml');
kmlwritepoint(filename2, LAT_MC', LONG_MC', 'Icon', iconFilename2, 'IconScale', 1, 'Name', Name_blank2);

%%%%%%%%%%%%%%%%
% Plot results %
%%%%%%%%%%%%%%%%
disp('Plot and save dark flight and strewn field model results')
disp('   ')

% Compute distance range from starting point, km
[arc,az] = distance(LAT,LONG,lat(1:100:N),long(1:100:N));
range=111.19*arc;

figure

subplot(2,3,1)
% Speed vs time
plot(t(1:N), speed/1000, 'k.', 'MarkerSize', 10)
hold on
grid
title('Speed vs time', 'FontSize',14) 
xlabel('Time (s)','FontSize',14)
ylabel('Velocity (km/s)','Fontsize',14)
hold off

subplot(2,3,2)
% Height vs time
plot(t(1:N), height/1000, 'k.', 'MarkerSize', 10)
hold on
grid
title('Height vs time', 'FontSize',14)
xlabel('Time (s)','FontSize',14)
ylabel('Height (km)','Fontsize',14)
hold off

subplot(2,3,3)
% Speed vs height
plot(height(1:100:N)/1000, speed(1:100:N)/1000, 'k.', 'MarkerSize', 10)
hold on
grid
title('Speed vs height', 'FontSize',14)
xlabel('Height (km)','FontSize',14)
ylabel('Speed (km/s)','Fontsize',14)
hold off

subplot(2,3,4)
% Height vs range
plot(range, height(1:100:N)/1000, 'k.', 'MarkerSize', 10)
hold on
grid
title('Height vs range', 'FontSize',14)
xlabel('Range (km)','FontSize',14)
ylabel('Height (km)','Fontsize',14)
hold off

subplot(2,3,5)
% Dark flight latitude vs longitude
plot(long(1:100:N), lat(1:100:N), 'k.', 'MarkerSize', 10)
hold on
plot(long(N), lat(N), 'r.', 'MarkerSize', 20)
grid
legend("On air", "Nominal impact point",'interpreter','latex')
title('Dark flight on the ground', 'FontSize',14)
xlabel('Long (deg)','FontSize',14)
ylabel('Lat (deg)','Fontsize',14)
hold off

subplot(2,3,6)
% Strewn field latitude vs longitude
plot(LONG_MC, LAT_MC, 'k.', 'MarkerSize', 10)
hold on
plot(long(N), lat(N), 'r.', 'MarkerSize', 20)
hold on
plot(101.894, 60.886, 'b+', 'MarkerSize', 20) % Tunguska Epicenter
hold on
plot(101.9167, 60.8967, 'r+', 'MarkerSize', 20) % John's Stone
hold on
plot(101.860278, 60.96389, 'b.', 'MarkerSize', 20) % Cheko Lake
grid
legend("Monte Carlo impact points", "Nominal impact point","Tunguska Epicenter","John's Stone", "Cheko Lake",'interpreter','latex')
title('Strewn field latitude vs longitude', 'FontSize',14)
xlabel('Long. strewn field (deg)','FontSize',14)
ylabel('Lat. strewn field (deg)','Fontsize',14)

suptitle(strcat('Dark flight and strewn field model', " ", fireball_name))

hold off

cd(working_path)
file_output=strcat('Dark_flight_MS_', num2str(round(M0/S0)), '_Ga_',num2str(Ga),'_I_',num2str(I0), '_',fireball_name,'.fig');
saveas(gcf, file_output, 'fig')   % Save the figure in .fig format
cd(WP)

disp('End dark flight and strewn field model computation')
disp('   ')