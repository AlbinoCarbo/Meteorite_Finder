% Function for the linear interpolation of wind speed, air density and temperature 
% between two different altitudes of the atmospheric profile.
%
% Input
% I = index of Q nearest to Qmet
% Qmet = meteoroid height, m
% Q = array winds speed, m
% T = array temperature, K
% rho = array air density, kg/m^3
% vx = x component wind speed in ECEF, m/s
% vy = y component wind speed in ECEF, m/s
% vz = z component wind speed in ECEF, m/s
%
% Output:
% Interpolated values of T (K), rho (kg/m^3), vx (m/s), vy (m/s), vz (m/s)
%
% Albino Carbognani, INAF-OAS
% Version Mar 9, 2023

function [Ti, rho_i, vxi, vyi, vzi]=interpolation(I, Qmet, Qw, T, rho, vx, vy, vz)

    if I > 1 && Qmet < Qw(I) && Qmet > Qw(I-1)
    
        % In the atmospheric profile two successive winds speed could be the same, these instructions 
        % avoid possible software crashes.
        if vx(I-1)~=vx(I) && vy(I-1)~=vy(I) && vz(I-1)~=vz(I)
        Ax=(Qw(I-1)-Qw(I))/(vx(I-1)-vx(I)); Bx=(vx(I-1)*Qw(I)-vx(I)*Qw(I-1))/(vx(I-1)-vx(I));
        Ay=(Qw(I-1)-Qw(I))/(vy(I-1)-vy(I)); By=(vy(I-1)*Qw(I)-vy(I)*Qw(I-1))/(vy(I-1)-vy(I));
        Az=(Qw(I-1)-Qw(I))/(vz(I-1)-vz(I)); Bz=(vz(I-1)*Qw(I)-vz(I)*Qw(I-1))/(vz(I-1)-vz(I));
        vxi=(Qmet/Ax)-(Bx/Ax); vyi=(Qmet/Ay)-(By/Ay); vzi=(Qmet/Az)-(Bz/Az);
        else
            vxi=vx(I); vyi=vy(I); vzi=vz(I);
        end
        
        A=(Qw(I-1)-Qw(I))/(rho(I-1)-rho(I)); B=(rho(I-1)*Qw(I)-rho(I)*Qw(I-1))/(rho(I-1)-rho(I));
        rho_i=(Qmet/A)-(B/A);
        
        % In the atmospheric profile two successive temperatures could be the same, these instructions 
        % avoid possible software crashes.
        
        if T(I-1)~=T(I)
        At=(Qw(I-1)-Qw(I))/(T(I-1)-T(I)); Bt=(T(I-1)*Qw(I)-T(I)*Qw(I-1))/(T(I-1)-T(I));
        Ti=(Qmet/At)-(Bt/At);
        end
        
        if T(I-1)==T(I)
            Ti=T(I);
        end
    end

    if I < length(vx) && Qmet < Qw(I+1) && Qmet > Qw(I)
    
        % In the atmospheric profile two successive winds speed could be the same, these instructions 
        % avoid possible software crashes.
        if vx(I+1)~=vx(I) && vy(I+1)~=vy(I) && vz(I+1)~=vz(I)
        Ax=(Qw(I)-Qw(I+1))/(vx(I)-vx(I+1)); Bx=(vx(I)*Qw(I+1)-vx(I+1)*Qw(I))/(vx(I)-vx(I+1));
        Ay=(Qw(I)-Qw(I+1))/(vy(I)-vy(I+1)); By=(vy(I)*Qw(I+1)-vy(I+1)*Qw(I))/(vy(I)-vy(I+1));
        Az=(Qw(I)-Qw(I+1))/(vz(I)-vz(I+1)); Bz=(vz(I)*Qw(I+1)-vz(I+1)*Qw(I))/(vz(I)-vz(I+1));
        vxi=(Qmet/Ax)-(Bx/Ax); vyi=(Qmet/Ay)-(By/Ay); vzi=(Qmet/Az)-(Bz/Az);
        else
            vxi=vx(I); vyi=vy(I); vzi=vz(I);
        end
        
        A=(Qw(I)-Qw(I+1))/(rho(I)-rho(I+1)); B=(rho(I)*Qw(I+1)-rho(I+1)*Qw(I))/(rho(I)-rho(I+1));
        rho_i=(Qmet/A)-(B/A);
        
        % In the atmospheric profile two successive temperatures could be the same, these instructions 
        % avoid possible software crashes.
        
        if T(I+1)~=T(I)
        At=(Qw(I)-Qw(I+1))/(T(I)-T(I+1)); Bt=(T(I)*Qw(I+1)-T(I+1)*Qw(I))/(T(I)-T(I+1));
        Ti=(Qmet/At)-(Bt/At);
        end
        
        if T(I+1)==T(I)
            Ti=T(I);
        end
        
    end
    
    if I==1
        Ti=T(I); rho_i=rho(I); vxi=vx(I); vyi=vy(I); vzi=vz(I);
    end
    
    if I==length(vx)
        Ti=T(I); rho_i=rho(I); vxi=vx(I); vyi=vy(I); vzi=vz(I);
    end
    
end