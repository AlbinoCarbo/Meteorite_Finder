% Matlab function for computing the uncertainty of the falling point of a 
% meteoroid using the Monte Carlo method.
%
% Input:
% M = Number of Monte Carlo scenarios, integer
% N = Final component number of the nominal scenario, integer
%
% Output:
% LAT_MC, LONG_MC = Lat and Long possible impact points (degrees)
%
% Albino Carbognani, INAF-OAS
% Version Mar 8, 2023

function [LAT_MC, LONG_MC]=Monte_Carlo_meteoroid(M, N)

% Reference ellipsoid for World Geodetic System of 1984.
% NOTE: by default, the lengths of the semimajor axis and semiminor axis are in
% meters.
wgs84 = wgs84Ellipsoid;

wholefile_set = fileread('.\Settings.txt');
% Split of the Settings and initialization of the string variables
set = regexp(wholefile_set,'\$+','split');

M0=str2double(strtrim(set{13}));          % Meteoroid mass, kg
V00=str2double(strtrim(set{19}));         % Starting speed, m/s
I00=str2double(strtrim(set{22}));         % Trajectory inclination at starting speed, degrees
A00=str2double(strtrim(set{25}));         % Trajectory azimut at starting speed, degrees
Q00=str2double(strtrim(set{28}));         % Starting height above Earth surface, m
LAT0=str2double(strtrim(set{31}));        % Latitude starting point, degrees
LONG0=str2double(strtrim(set{34}));       % Longitude starting point, degrees
T0=str2double(strtrim(set{40}));          % Maximum integration time, s
uV0=str2double(strtrim(set{55}));         % Uncertainty starting speed, m/s    
uI0=str2double(strtrim(set{58}));         % Uncertainty Trajectory inclination at starting speed, degree
uA0=str2double(strtrim(set{61}));         % Uncertainty Trajectory azimut at starting speed, degree (from north to east)
uQ0=str2double(strtrim(set{64}));         % Uncertainty Starting height above Earth surface, m 
uLAT=str2double(strtrim(set{67}));        % Uncertainty Latitude starting point, degree
uLONG=str2double(strtrim(set{70}));       % Uncertainty Longitude starting point, degree

% Initialization of Monte Carlo scenario final vectors
LAT_MC=zeros(1, M); 
LONG_MC=zeros(1, M); 

disp('   ')
disp('START MONTE CARLO COMPUTATION')
disp('   ')

for i=1:M

    % Monte Carlo scenario generation
    V0 = abs(V00 + (uV0)*(randn));       % New starting speed, m/s
    I0 = abs(I00 + (uI0)*(randn));       % New inclination, degrees
    A0 = abs(A00 + (uA0)*(randn));       % New azimut, degrees
    Q0 = abs(Q00 + (uQ0)*(randn));       % New starting height, m
    LAT = LAT0 + (uLAT)*(randn);         % New starting latitude, degree
    LONG = LONG0 + (uLONG)*(randn);      % New starting longitude, degree
    
    % NOTE: randn is a random number with standard normal distribution, ie with average value
    % zero and standard deviation 1.
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Compute meteoroid starting speed in ECEF reference system %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    disp(strcat('Monte Carlo'," ", num2str(i), " ", ': Compute meteoroid starting speed in ECEF reference system'))
    disp('   ')

    V_north=-V0*cosd(I0)*cosd(A0); % Speed component towards north, m/s
    V_east=-V0*cosd(I0)*sind(A0);  % Speed component towards east, m/s
    V_down=V0*sind(I0);            % Speed component down, m/s

    [VX0, VY0, VZ0]=ned2ecefv(V_north, V_east, V_down, LAT, LONG);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Compute meteoroid starting position in ECEF reference system %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    disp(strcat('Monte Carlo'," ", num2str(i), " ", ': Compute meteoroid starting position in ECEF reference system'))
    disp('   ')

    % Compute ECEF coordinates of starting point, m 
    [X0, Y0, Z0] = geodetic2ecef(wgs84,LAT,LONG,Q0);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Vector of starting conditions, speed (km/s) and position (m), in ECEF system %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    disp(strcat('Monte Carlo'," ", num2str(i), " ", ': Define starting conditions vector'))
    disp('   ')
    y0=[VX0 VY0 VZ0 X0 Y0 Z0 M0];

    % Integration time vector, s
    tspan=0:0.01:T0;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Numerical integration of the equations of motion %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    disp(strcat('Monte Carlo'," ", num2str(i), " ", ': Integrate motion equations'))
    disp('   ')

    % Runge-Kutta 4th/5th order ODE solver
    [t, y]=ode45(@ODEsystem, tspan, y0);

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % Compute meteoroid lat and long final point %
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   disp(strcat('Monte Carlo'," ", num2str(i), " ", ': Compute meteoroid height, lat and long'))
   disp('   ')

   [LAT_MC(i), LONG_MC(i), ~]=ecef2geodetic(wgs84, y(N, 4), y(N, 5), y(N, 6));

end

disp('   ')
disp('END MONTE CARLO COMPUTATION')
disp('   ')

end